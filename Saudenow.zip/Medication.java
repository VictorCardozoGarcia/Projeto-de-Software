import java.time.LocalDateTime;

public class Medication {
  private final String name;
  private LocalDateTime timeToTake;

  public Medication(String name, LocalDateTime timeToTake) {
    if (name == null || name.trim().isEmpty()) {
        throw new IllegalArgumentException("O nome não pode ser nulo ou vazio");
    }
    if (timeToTake == null) {
        throw new IllegalArgumentException("O horário de tomar não pode ser nulo");
    }

    this.name = name;
    this.timeToTake = timeToTake;
  }

  // Getters
  public String getName() {
    return name;
  }

  public LocalDateTime getTimeToTake() {
    return timeToTake;
  }

  // Methods
  public void sendAlert() {
    // Uma implementação básica; em um sistema real, isso pode ser mais sofisticado
    System.out.println("Lembrete: Hora de tomar " + name);
  }
}

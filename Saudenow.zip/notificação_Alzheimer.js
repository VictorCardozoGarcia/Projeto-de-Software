let hasTakenMedication = false;

function sendMedicationNotification() {
    if (dosesLeft > 0 && !hasTakenMedication) {
        const userConfirmation = confirm(`Hora de tomar o medicamento ${medicationName}. Você tomou?`);
        if (userConfirmation) {
            dosesLeft--;
            hasTakenMedication = true;

            // Se desejar, armazene o horário e a data de confirmação aqui

            // Reconfigura o alarme para o próximo dia no mesmo horário
            setTimeout(() => {
                hasTakenMedication = false;
                sendMedicationNotification();
            }, 24 * 60 * 60 * 1000);  // 24 horas
        } else {
            // Reenvie a notificação após um intervalo (por exemplo, 30 minutos)
            setTimeout(() => {
                sendMedicationNotification();
            }, 30 * 60 * 1000);
        }
    } else if (dosesLeft === 0) {
        alert(`Acabaram as doses do medicamento ${medicationName}. Por favor, compre mais.`);
    }
}

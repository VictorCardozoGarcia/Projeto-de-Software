public class Elderly {
    private String name;
    private int age;
    private boolean hasConditions;    // Atributo da primeira classe
    private boolean hasAlzheimer;     // Atributo da segunda classe

    public Elderly(String name, int age, boolean hasConditions, boolean hasAlzheimer) {
        setName(name);
        setAge(age);
        this.hasConditions = hasConditions;
        this.hasAlzheimer = hasAlzheimer;
    }

    // Getters
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public boolean hasConditions() {
        return hasConditions;
    }

    public boolean hasAlzheimer() {
        return hasAlzheimer;
    }

    // Setters com validações
    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("O campo nome está incompatível.");
        }
        this.name = name;
    }

    public void setAge(int age) {
        if (age < 0) {
            throw new IllegalArgumentException("Idade não pode ser negativa.");
        }
        this.age = age;
    }

    public void setHasConditions(boolean hasConditions) {
        this.hasConditions = hasConditions;
    }

    public void setHasAlzheimer(boolean hasAlzheimer) {
        this.hasAlzheimer = hasAlzheimer;
    }

    @Override
    public String toString() {
        return name + ", " + age + " anos de idade" + 
               (hasConditions ? ", tem condições de saúde" : "") + 
               (hasAlzheimer ? ", tem Alzheimer's" : "");
    }
}

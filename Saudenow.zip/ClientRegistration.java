import javax.swing.*;
import java.sql.*;

public class ClientRegistration {

    private JFrame frame;
    private JTextField nameField, ageField, weightField, medsField, streetField, numField, cepField, cityField, stateField;
    private JButton saveButton;

    public ClientRegistration() {
        frame = new JFrame("Registrando Usuario");

        // Creating interface components
        JLabel nameLabel = new JLabel("Nome:");
        nameField = new JTextField(20);

        JLabel ageLabel = new JLabel("Idade:");
        ageField = new JTextField(20);

        JLabel weightLabel = new JLabel("Peso:");
        weightField = new JTextField(20);

        JLabel medsLabel = new JLabel("Medicações:");
        medsField = new JTextField(20);

        JLabel streetLabel = new JLabel("Rua:");
        streetField = new JTextField(20);

        JLabel numLabel = new JLabel("Numero:");
        numField = new JTextField(20);

        JLabel cepLabel = new JLabel("CEP:");
        cepField = new JTextField(20);

        JLabel cityLabel = new JLabel("Cidade:");
        cityField = new JTextField(20);

        JLabel stateLabel = new JLabel("Estado:");
        stateField = new JTextField(20);

        saveButton = new JButton("Salvar");
        saveButton.addActionListener(e -> {
            if (validateFields()) {
                saveData();
            } else {
                JOptionPane.showMessageDialog(frame, "Por favor, verifique os dados inseridos.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Adding components to the frame
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(ageLabel);
        frame.add(ageField);
        frame.add(weightLabel);
        frame.add(weightField);
        frame.add(medsLabel);
        frame.add(medsField);
        frame.add(streetLabel);
        frame.add(streetField);
        frame.add(numLabel);
        frame.add(numField);
        frame.add(cepLabel);
        frame.add(cepField);
        frame.add(cityLabel);
        frame.add(cityField);
        frame.add(stateLabel);
        frame.add(stateField);
        frame.add(saveButton);

        frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private boolean validateFields() {
        try {
            Integer.parseInt(ageField.getText());
            Float.parseFloat(weightField.getText());
        } catch (NumberFormatException e) {
            return false;
        }

        return !nameField.getText().isEmpty() 
            && !streetField.getText().isEmpty()
            && !medsField.getText().isEmpty()
            && !numField.getText().isEmpty()
            && !cepField.getText().isEmpty()
            && !cityField.getText().isEmpty()
            && !stateField.getText().isEmpty();
    }

    private void saveData() {
        String name = nameField.getText();
        int age = Integer.parseInt(ageField.getText());
        float weight = Float.parseFloat(weightField.getText());
        String meds = medsField.getText();
        String street = streetField.getText();
        String num = numField.getText();
        String cep = cepField.getText();
        String city = cityField.getText();
        String state = stateField.getText();

        // Connect to database and save (using SQLite as example)
        try {
            // Load SQLite JDBC driver (if needed)
            Class.forName("org.sqlite.JDBC");
            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:clients.db")) {
            
                String sql = "CREATE TABLE IF NOT EXISTS cliente (id INTEGER PRIMARY KEY, nome TEXT, idade INTEGER, peso REAL, remedios TEXT, rua TEXT, numero TEXT, cep TEXT, cidade TEXT, estado TEXT)";
                try (Statement stmt = conn.createStatement()) {
                    stmt.execute(sql);
                }

                sql = "INSERT INTO cliente(nome, idade, peso, remedios, rua, numero, cep, cidade, estado) VALUES(?,?,?,?,?,?,?,?,?)";
            
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, name);
                    pstmt.setInt(2, age);
                    pstmt.setFloat(3, weight);
                    pstmt.setString(4, meds);
                    pstmt.setString(5, street);
                    pstmt.setString(6, num);
                    pstmt.setString(7, cep);
                    pstmt.setString(8, city);
                    pstmt.setString(9, state);

                    pstmt.executeUpdate();
                }

                JOptionPane.showMessageDialog(frame, "Dados salvos com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(frame, "Ocorreu um erro ao salvar os dados.", "Erro de Banco de Dados", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(frame, "Driver SQLite não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new ClientRegistration();
    }
}

import java.time.LocalDateTime;

/**
 * Represents an appointment with a doctor.
 */
public class Appointment {
    private final Elderly patient;
    private final Doctor doctor;
    private LocalDateTime date;
    private String reason;
    private String location;
    private Status status;

    public enum Status {
        SCHEDULED, CANCELLED, COMPLETED
    }

    /**
     * Creates an appointment.
     * @param patient The elderly patient.
     * @param doctor The attending doctor.
     * @param date The date of the appointment.
     * @param reason The reason for the appointment.
     * @param location The location of the appointment.
     */
    public Appointment(Elderly patient, Doctor doctor, LocalDateTime date, String reason, String location) {
        if (patient == null || doctor == null || date == null || reason == null || location == null) {
            throw new IllegalArgumentException("Arguments cannot be null");
        }

        this.patient = patient;
        this.doctor = doctor;
        setDate(date);
        setReason(reason);
        setLocation(location);
        this.status = Status.SCHEDULED;
    }

    // Getters
    public Elderly getPatient() {
        return this.patient;
    }

    public Doctor getDoctor() {
        return this.doctor;
    }

    public LocalDateTime getDate() {
        return this.date;
    }

    public String getReason() {
        return this.reason;
    }

    public void setDate(LocalDateTime date) {
        if (date == null) {
            throw new IllegalArgumentException("Date cannot be null");
        }
        this.date = date;
    }

    public void setReason(String reason) {
        if (reason == null || reason.trim().isEmpty()) {
            throw new IllegalArgumentException("Reason cannot be null or empty");
        }
        this.reason = reason;
    }

    public void setLocation(String location) {
        if (location == null || location.trim().isEmpty()) {
            throw new IllegalArgumentException("Location cannot be null or empty");
        }
        this.location = location;
    }

    @Override
    public String toString() {
        return "Appointment with Dr. " + doctor.getName()
                + " on " + date + " at " + location
                + ". Reason: " + reason
                + ". Status: " + status;
    }
}

/**
 * Represents an elderly patient.
 */
class Elderly {
    // Implementations as needed
}

/**
 * Represents a doctor.
 */
class Doctor {
    private String name;

    /**
     * Creates a new doctor.
     * @param name The name of the doctor.
     */
    public Doctor(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Doctor's name cannot be null or empty");
        }
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

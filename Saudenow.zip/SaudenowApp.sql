CREATE TABLE Users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    age INTEGER NOT NULL,
    weight REAL NOT NULL,
    street TEXT NOT NULL,
    num TEXT NOT NULL,
    cep TEXT NOT NULL,
    city TEXT NOT NULL,
    state TEXT NOT NULL,
    has_alzheimer BOOLEAN NOT NULL
);

CREATE TABLE Medications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    medication_name TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES Users(id)
);

CREATE TABLE Doctors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    specialty TEXT NOT NULL
);

CREATE TABLE Appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    doctor_id INTEGER,
    date DATETIME NOT NULL,
    reason TEXT NOT NULL,
    location TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES Users(id),
    FOREIGN KEY(doctor_id) REFERENCES Doctors(id)
);

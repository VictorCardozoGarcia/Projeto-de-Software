public class Doctor {

    private String name;
    private String specialty;

    public Doctor(String name, String specialty) {
        if (name == null || specialty == null) {
            throw new IllegalArgumentException("Nome ou especialidade não pode ser nulo");
        }
        this.name = name;
        this.specialty = specialty;
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public String getSpecialty() {
        return specialty;
    }

    // Setter methods (optional, if you want to allow modification after creation)
    public void setName(String name) {
        if (name == null) {
            throw new IllegalArgumentException("O nome não pode ser nulo");
        }
        this.name = name;
    }

    public void setSpecialty(String specialty) {
        if (specialty == null) {
            throw new IllegalArgumentException("Especialidade não pode ser nula");
        }
        this.specialty = specialty;
    }

    @Override
    public String toString() {
        return name + ", especialidade: " + specialty;
    }
}

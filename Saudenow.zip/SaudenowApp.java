import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SaudenowApp {

    private final List<Elderly> elderlyList = new ArrayList<>();
    private final List<Medication> medicationList = new ArrayList<>();
    private final List<Doctor> doctorsList = new ArrayList<>();
    private final List<Appointment> appointmentsList = new ArrayList<>();

    // Methods to manage Elderly
    public void addElderly(Elderly elderly) {
        if (elderly == null) {
            throw new IllegalArgumentException("Elderly cannot be null");
        }
        elderlyList.add(elderly);
    }

    // Methods to manage Medication
    public void addMedication(Medication medication) {
        if (medication == null) {
            throw new IllegalArgumentException("Medication cannot be null");
        }
        medicationList.add(medication);
    }

    public void sendMedicationAlert(Medication medication) {
        if (medication == null) {
            throw new IllegalArgumentException("Medication cannot be null");
        }
        medication.sendAlert();
    }

    // Methods to manage Doctor
    public void addDoctor(Doctor doctor) {
        if (doctor == null) {
            throw new IllegalArgumentException("Doctor cannot be null");
        }
        doctorsList.add(doctor);
    }

    // Methods to manage Appointments
    public void scheduleAppointment(Elderly patient, Doctor doctor, LocalDateTime date, String reason) {
        if (patient == null || doctor == null || date == null || reason == null) {
            throw new IllegalArgumentException("Arguments cannot be null");
        }
        Appointment appointment = new Appointment(patient, doctor, date, reason);
        appointmentsList.add(appointment);
    }
  

public void scheduleAppointment(Elderly patient, Doctor doctor, LocalDateTime date, String reason, String location) {
    if (patient == null || doctor == null || date == null || reason == null || location == null) {
        throw new IllegalArgumentException("Arguments cannot be null");
    }
    Appointment appointment = new Appointment(patient, doctor, date, reason, location);
    appointmentsList.add(appointment);
}
    // Optional: Print methods for each list
    public void printElderlyList() {
        for (Elderly e : elderlyList) {
            System.out.println(e);
        }
    }

    public void printMedicationList() {
        for (Medication m : medicationList) {
            System.out.println(m.getName() + ", to be taken at: " + m.getTimeToTake());
        }
    }

    public void printDoctorsList() {
        for (Doctor d : doctorsList) {
            System.out.println(d);
        }
    }

    public void printAppointmentsList() {
        for (Appointment a : appointmentsList) {
            System.out.println("Appointment for " + a.getPatient() + " with " + a.getDoctor() + " on " + a.getDate() + " for " + a.getReason());
        }
    }

    // Método main (ponto de entrada)
    public static void main(String[] args) {
        SaudenowApp app = new SaudenowApp();

        Elderly john = new Elderly("John Doe", 70, false);
        Elderly jane = new Elderly("Jane Smith", 65, true);
        Doctor drSmith = new Doctor("Dr. Smith", "Geriatrics");
        Medication med1 = new Medication("Medicine A", LocalDateTime.now());

        app.addElderly(john);
        app.addElderly(jane);
        app.addDoctor(drSmith);
        app.addMedication(med1);

        // Criando uma consulta
        LocalDateTime appointmentDate = LocalDateTime.now().plusDays(3);  // Apenas um exemplo
        app.scheduleAppointment(john, drSmith, appointmentDate, "Consulta de rotina", "Consultório 102");

        // Imprimindo as listas
        app.printElderlyList();
        app.printDoctorsList();
        app.printMedicationList();
    }
}

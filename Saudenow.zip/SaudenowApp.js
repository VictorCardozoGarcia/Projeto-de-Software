function saveToFile() {
    // Obter os valores dos campos
    let name = document.getElementById('name').value;
    let age = document.getElementById('age').value;
    let weight = document.getElementById('weight').value;
    // ... obtenha os outros valores da mesma maneira ...

    // Formatar os dados para salvar
    let data = 
        `Nome: ${name}\n` +
        `Idade: ${age}\n` +
        `Peso: ${weight}\n`
        // ... continue para os outros campos ...

    // Criar um "blob" com os dados
    let blob = new Blob([data], { type: 'text/plain' });
    let a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${name}.txt`; // Define o nome do arquivo como o nome do usuário

    // Acionar o download
    a.click();
}

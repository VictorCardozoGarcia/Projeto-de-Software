let dosesLeft;
let medicationName;

function setupMedicationAlert() {
    medicationName = document.getElementById("medication-name-alert").value;
    const timeToTake = document.getElementById("time-to-take-alert").value;
    dosesLeft = parseInt(document.getElementById("total-doses").value);

    if (dosesLeft <= 0) {
        alert("Por favor, insira um número válido de doses.");
        return;
    }

    const currentDateTime = new Date();
    const medicationTime = new Date(currentDateTime.toDateString() + " " + timeToTake);

    // Se o horário escolhido já passou, configurar para o próximo dia
    if (currentDateTime > medicationTime) {
        medicationTime.setDate(medicationTime.getDate() + 1);
    }

    const timeDiff = medicationTime - currentDateTime;
    
    setTimeout(() => {
        sendMedicationNotification();
    }, timeDiff);
}

function sendMedicationNotification() {
    if (dosesLeft > 0) {
        alert(`Hora de tomar o medicamento ${medicationName}. Restam ${dosesLeft} doses.`);
        dosesLeft--;

        // Reconfigura o alarme para o próximo dia no mesmo horário
        setTimeout(() => {
            sendMedicationNotification();
        }, 24 * 60 * 60 * 1000);  // 24 horas
    } else {
        alert(`Acabaram as doses do medicamento ${medicationName}. Por favor, compre mais.`);
    }
}
